from Field import Field
from ML import ML
from DB import db, Mdp
import random


def initDB():
    #db.create_all()

    loop = 0

    while loop < 300000:
        if loop % 1000 == 0:
            print ("loop:\t %r" % loop)

        field = Field()

        ml = ML()
        ml.setAlpha(0.1)

        loop += 1
        mdpX = []

        while True:
            #########################################
            # action 1
            #########################################

            while True:
                action1 = random.randint(0, 8)
                res = field.setField(action1, 'O')
                if res == 1 or res == 0:
                    break

            state = field.isState()

            if state == field.END:
                break
            elif state == 'O':
                reward = -1
                for mdp in mdpX:
                    list_state = list(mdp.state)
                    for x in range(9):
                        if x != mdp.action and list_state[x] == 'B':
                            ml.learn(Mdp(mdp.state, x), 0.)
                    ml.learn(mdp, reward)
                    reward += -1
                break

            #########################################
            # action 2
            #########################################

            stateX = field.getState()

            while True:
                action2 = ml.getAction(stateX)
                res = field.setField(action2, 'X')

                if res == 1 or res == 0:
                    if res == 1:
                        state_x = Mdp(stateX, action2, 0.)
                        mdpX.append(state_x)
                    break

            state = field.isState()

            if state == field.END:
                break
            elif state == 'X':
                plus = 1
                for d in mdpX:
                    ml.learn(d, plus)
                    plus += 1
                break

    print ("X db:\t%r" % len(Mdp.query.all()))
