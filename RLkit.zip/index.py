from flask import render_template, request, jsonify
from ML import ML
from initDB import initDB
from Field import Field2
from DB import app, db


@app.route('/')
def index():
    entries_list = ['B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B']
    return render_template('index.html', entries=entries_list)


@app.route('/click', methods=['POST'])
def click():
    frState = request.form['state']
    data = {}

    ml = ML()

    field = Field2(frState)
    now_state = field.isState()
    if now_state == 'O' or now_state == field.END:
        data['state'] = now_state
        data['result'] = list(frState)
        return jsonify(data)

    list_result = list(frState)
    list_result[ml.getAction(frState)] = 'X'

    data['result'] = list_result
    data['state'] = 'NOTEND'

    fieldO = Field2(data['result'])
    result_state = fieldO.isState()
    if result_state == 'X' or result_state == fieldO.END:
        data['state'] = result_state
        return jsonify(data)

    return jsonify(data)

if __name__ == '__main__':
    db.create_all()
    initDB()
    app.run(port=3000)
