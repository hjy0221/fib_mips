from DB import db, Mdp
import random


class ML:

    def __init__(self):
        self._alpha = 0.

    def setAlpha(self, alpha):
        self._alpha = alpha

    def learn(self, mdb_block, reward):
        mdb_block.reward = reward
        q = Mdp.query.filter(Mdp.state == mdb_block.state).filter(Mdp.action == mdb_block.action).first()

        if None == q:
            mdb_block.reward = self._alpha * mdb_block.reward
            db.session.add(mdb_block)
            db.session.commit()
        else:
            old = q.reward
            q.reward = old + self._alpha * (mdb_block.reward - old)
            db.session.commit()

    def getAction(self, state):
        st_List = list(state)
        states = Mdp.query.filter(Mdp.state == state).all()
        action = 0

        if len(states) == 0:
            while True:
                id_ = random.randint(0, 8)
                if st_List[id_] == 'B':
                    action = id_
                    break
        else:
            on = True
            reward = 0.
            for x in states:
                if reward < x.reward or on:
                    if on:
                        on = False
                    reward = x.reward
                    action = x.action
        return action
