
class Field:
    def __init__(self):
        self._field =['B', 'B','B','B','B','B','B','B','B']
        self.END = 'END'
        self.NOTEND = 'NOTEND'


    def setField(self, idx, letter):
        if self._field.count('B') == 0:
            return 0
        elif self._field[idx] == 'B':
            self._field[idx] = letter
            return 1
        else:
            return 2

    def getState(self):
        str = ''
        for x in self._field:
            str += x
        return str

    def isState(self):
        if self._field.count('B') != 9:
            if self._field[0] != 'B' and self._field[0] == self._field[1] == self._field[2]:
                return self._field[0]
            elif self._field[3] != 'B' and self._field[3] == self._field[4] == self._field[5]:
                return self._field[3]
            elif self._field[6] != 'B' and self._field[6] == self._field[7] == self._field[8]:
                return self._field[6]
            elif self._field[0] != 'B' and self._field[0] == self._field[3] == self._field[6]:
                return self._field[0]
            elif self._field[1] != 'B' and self._field[1] == self._field[4] == self._field[7]:
                return self._field[1]
            elif self._field[2] != 'B' and self._field[2] == self._field[5] == self._field[8]:
                return self._field[2]
            elif self._field[0] != 'B' and self._field[0] == self._field[4] == self._field[8]:
                return self._field[0]
            elif self._field[2] != 'B' and self._field[2] == self._field[4] == self._field[6]:
                return self._field[2]

            elif self._field.count('B') == 0:
                return self.END

            else:
                return self.NOTEND

        else:
            return 'NOCHANGE'


class Field2(Field):
    def __init__(self, state):
        Field.__init__(self)
        self._field = list(state)
