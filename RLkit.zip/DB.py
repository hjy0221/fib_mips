from flask import Flask
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True

db = SQLAlchemy(app)


class Mdp(db.Model):

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    state = db.Column(db.String(9))
    action = db.Column(db.Integer)
    reward = db.Column(db.Float)

    def __init__(self, state, action, reward=0.):
        self.action = action
        self.state = state
        self.reward = reward

    def __repr__(self):
        return '<Mdp %r %r %r>' % (self.state, self.action, self.reward)